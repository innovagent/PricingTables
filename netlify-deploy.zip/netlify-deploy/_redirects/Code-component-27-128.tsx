# Netlify redirects and rewrites
/*    /index.html   200

# Widget embedding endpoint
/widget/*   /index.html   200

# API proxy for forms (if needed in future)
/api/*  /.netlify/functions/:splat  200